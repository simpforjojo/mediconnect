# Popup Chat window (chat bot) using html,css,js
Website link : https://krishnaprasadek.github.io/Popup-chat-window/


A Complete Responsive homepage with a navigation bar and Chat Popup.
Chat by clicking on the bottom-right floating-action-button.
Added some small button click sounds and message sent and receive notification sounds for better user experience.


Mock conversation by using text given by the following API (https://api.adviceslip.com/advice).
When you sent something you will get some random quotes as reply.

Thanks...
